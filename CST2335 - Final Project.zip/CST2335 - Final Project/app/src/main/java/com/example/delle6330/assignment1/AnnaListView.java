package com.example.delle6330.assignment1;

import android.app.Activity;
import android.os.Bundle;

public class AnnaListView extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anna_list_view2);
    }
}
